import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertTriangle, Tag, Truck, ShoppingCart, Settings } from 'lucide-react';
import { shops } from '@/data/mockData';
import LowStockTab from '@/components/LowStockTab';
import BrandsTab from '@/components/BrandsTab';
import SuppliersTab from '@/components/SuppliersTab';
import ReorderTab from '@/components/ReorderTab';
import SettingsTab from '@/components/SettingsTab';

const Index = () => {
  const [selectedShopId, setSelectedShopId] = useState(shops[0].id);

  return (
    <div className="min-h-screen bg-background">
      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-30 border-b bg-card">
        <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <ShoppingCart className="h-4 w-4 text-primary-foreground" />
            </div>
            <h1 className="text-lg font-semibold tracking-tight">POS Manager</h1>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">Shop:</span>
            <Select value={selectedShopId} onValueChange={setSelectedShopId}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {shops.map(shop => (
                  <SelectItem key={shop.id} value={shop.id}>
                    {shop.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </header>

      {/* Main Content with Tabs */}
      <main className="mx-auto max-w-7xl px-4 py-4">
        <Tabs defaultValue="lowstock" className="space-y-4">
          <TabsList className="h-10">
            <TabsTrigger value="lowstock" className="gap-1.5">
              <AlertTriangle className="h-4 w-4" /> Low Stock
            </TabsTrigger>
            <TabsTrigger value="brands" className="gap-1.5">
              <Tag className="h-4 w-4" /> Brands
            </TabsTrigger>
            <TabsTrigger value="suppliers" className="gap-1.5">
              <Truck className="h-4 w-4" /> Suppliers
            </TabsTrigger>
            <TabsTrigger value="reorder" className="gap-1.5">
              <ShoppingCart className="h-4 w-4" /> Reorder
            </TabsTrigger>
            <TabsTrigger value="settings" className="gap-1.5">
              <Settings className="h-4 w-4" /> Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="lowstock">
            <LowStockTab selectedShopId={selectedShopId} />
          </TabsContent>
          <TabsContent value="brands">
            <BrandsTab />
          </TabsContent>
          <TabsContent value="suppliers">
            <SuppliersTab />
          </TabsContent>
          <TabsContent value="reorder">
            <ReorderTab selectedShopId={selectedShopId} />
          </TabsContent>
          <TabsContent value="settings">
            <SettingsTab selectedShopId={selectedShopId} />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default Index;
