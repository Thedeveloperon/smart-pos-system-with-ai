// ===== Core Entities =====

export interface Shop {
  id: string;
  name: string;
  code: string;
}

export interface Brand {
  id: string;
  name: string;
  code: string;
  isActive: boolean;
  productCount: number;
}

export interface Supplier {
  id: string;
  name: string;
  code: string;
  contactPerson: string;
  phone: string;
  email: string;
  address: string;
  defaultLeadTimeDays: number;
  paymentTerms: string;
  notes: string;
  isActive: boolean;
}

export interface Product {
  id: string;
  name: string;
  sku: string;
  brandId: string;
  brandName: string;
  category: string;
  unitPrice: number;
}

export interface ShopInventory {
  productId: string;
  shopId: string;
  currentStock: number;
  reorderLevel: number;
  safetyStock: number;
  targetStockLevel: number;
  allowNegativeStock: boolean;
}

export interface ProductSupplierLink {
  id: string;
  productId: string;
  supplierId: string;
  supplierSku: string;
  isPreferred: boolean;
  leadTimeDays: number;
  minOrderQty: number;
  packSize: number;
  lastPurchasePrice: number;
}

// ===== Computed / View Models =====

export interface LowStockItem {
  product: Product;
  shopId: string;
  shopName: string;
  currentStock: number;
  reorderLevel: number;
  deficit: number;
  preferredSupplier?: string;
  lastPurchasePrice: number;
}

export interface ReorderSuggestion {
  id: string;
  product: Product;
  supplierId: string;
  supplierName: string;
  currentStock: number;
  reorderLevel: number;
  suggestedQty: number;
  lastCost: number;
  leadTimeDays: number;
}

export interface DraftOrderLine {
  productId: string;
  productName: string;
  sku: string;
  qty: number;
  unitCost: number;
  total: number;
}

export interface DraftOrder {
  id: string;
  supplierId: string;
  supplierName: string;
  status: 'Draft' | 'Confirmed';
  lines: DraftOrderLine[];
  notes: string;
  createdAt: string;
  totalAmount: number;
}

export interface ShopStockSettings {
  lowStockThreshold: number;
  safetyStock: number;
  leadTimeDays: number;
  targetDaysOfCover: number;
}
