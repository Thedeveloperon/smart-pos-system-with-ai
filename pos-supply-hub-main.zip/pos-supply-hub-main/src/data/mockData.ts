import type { Shop, Brand, Supplier, Product, ShopInventory, ProductSupplierLink, DraftOrder, ShopStockSettings } from './types';

export const shops: Shop[] = [
  { id: 'shop-1', name: 'Main Street Store', code: 'MS01' },
  { id: 'shop-2', name: 'Downtown Branch', code: 'DT02' },
  { id: 'shop-3', name: 'Mall Outlet', code: 'ML03' },
];

export const brands: Brand[] = [
  { id: 'b1', name: 'Coca-Cola', code: 'CC', isActive: true, productCount: 4 },
  { id: 'b2', name: 'Pepsi', code: 'PP', isActive: true, productCount: 3 },
  { id: 'b3', name: "Lay's", code: 'LY', isActive: true, productCount: 3 },
  { id: 'b4', name: 'Nestlé', code: 'NS', isActive: true, productCount: 3 },
  { id: 'b5', name: 'Dettol', code: 'DT', isActive: false, productCount: 2 },
  { id: 'b6', name: 'Colgate', code: 'CG', isActive: true, productCount: 2 },
];

export const suppliers: Supplier[] = [
  { id: 's1', name: 'Metro Beverages Ltd', code: 'MBL', contactPerson: 'John Smith', phone: '+1-555-0101', email: 'john@metrobev.com', address: '123 Industrial Ave, City', defaultLeadTimeDays: 3, paymentTerms: 'Net 30', notes: 'Reliable delivery, bulk discounts available', isActive: true },
  { id: 's2', name: 'Snack World Distributors', code: 'SWD', contactPerson: 'Sarah Lee', phone: '+1-555-0202', email: 'sarah@snackworld.com', address: '456 Commerce Blvd, Town', defaultLeadTimeDays: 5, paymentTerms: 'Net 15', notes: 'Minimum order $500', isActive: true },
  { id: 's3', name: 'Household Supplies Co', code: 'HSC', contactPerson: 'Mike Brown', phone: '+1-555-0303', email: 'mike@householdsup.com', address: '789 Market St, Village', defaultLeadTimeDays: 7, paymentTerms: 'Net 45', notes: '', isActive: true },
  { id: 's4', name: 'Fresh Foods Direct', code: 'FFD', contactPerson: 'Anna Chen', phone: '+1-555-0404', email: 'anna@freshfoods.com', address: '321 Farm Rd, County', defaultLeadTimeDays: 2, paymentTerms: 'COD', notes: 'Perishable items, cold chain required', isActive: true },
];

export const products: Product[] = [
  { id: 'p1', name: 'Coca-Cola 330ml', sku: 'CC-330', brandId: 'b1', brandName: 'Coca-Cola', category: 'Beverages', unitPrice: 1.5 },
  { id: 'p2', name: 'Coca-Cola 1.5L', sku: 'CC-1500', brandId: 'b1', brandName: 'Coca-Cola', category: 'Beverages', unitPrice: 2.8 },
  { id: 'p3', name: 'Diet Coke 330ml', sku: 'DC-330', brandId: 'b1', brandName: 'Coca-Cola', category: 'Beverages', unitPrice: 1.5 },
  { id: 'p4', name: 'Sprite 330ml', sku: 'SP-330', brandId: 'b1', brandName: 'Coca-Cola', category: 'Beverages', unitPrice: 1.4 },
  { id: 'p5', name: 'Pepsi 330ml', sku: 'PP-330', brandId: 'b2', brandName: 'Pepsi', category: 'Beverages', unitPrice: 1.5 },
  { id: 'p6', name: 'Pepsi Max 330ml', sku: 'PM-330', brandId: 'b2', brandName: 'Pepsi', category: 'Beverages', unitPrice: 1.5 },
  { id: 'p7', name: '7UP 330ml', sku: '7U-330', brandId: 'b2', brandName: 'Pepsi', category: 'Beverages', unitPrice: 1.4 },
  { id: 'p8', name: "Lay's Classic 150g", sku: 'LY-CL-150', brandId: 'b3', brandName: "Lay's", category: 'Snacks', unitPrice: 3.2 },
  { id: 'p9', name: "Lay's BBQ 150g", sku: 'LY-BB-150', brandId: 'b3', brandName: "Lay's", category: 'Snacks', unitPrice: 3.2 },
  { id: 'p10', name: "Lay's Sour Cream 150g", sku: 'LY-SC-150', brandId: 'b3', brandName: "Lay's", category: 'Snacks', unitPrice: 3.2 },
  { id: 'p11', name: 'Nestlé KitKat 4-Finger', sku: 'NS-KK-4F', brandId: 'b4', brandName: 'Nestlé', category: 'Confectionery', unitPrice: 1.8 },
  { id: 'p12', name: 'Nestlé Milo 400g', sku: 'NS-MI-400', brandId: 'b4', brandName: 'Nestlé', category: 'Beverages', unitPrice: 5.5 },
  { id: 'p13', name: 'Nescafé Gold 200g', sku: 'NS-NC-200', brandId: 'b4', brandName: 'Nestlé', category: 'Beverages', unitPrice: 8.9 },
  { id: 'p14', name: 'Dettol Soap 100g', sku: 'DT-SP-100', brandId: 'b5', brandName: 'Dettol', category: 'Household', unitPrice: 2.1 },
  { id: 'p15', name: 'Dettol Handwash 250ml', sku: 'DT-HW-250', brandId: 'b5', brandName: 'Dettol', category: 'Household', unitPrice: 3.5 },
  { id: 'p16', name: 'Colgate Total 150g', sku: 'CG-TT-150', brandId: 'b6', brandName: 'Colgate', category: 'Personal Care', unitPrice: 3.8 },
  { id: 'p17', name: 'Colgate Mouthwash 500ml', sku: 'CG-MW-500', brandId: 'b6', brandName: 'Colgate', category: 'Personal Care', unitPrice: 5.2 },
];

export const shopInventory: ShopInventory[] = [
  // Main Street Store - some items critically low
  { productId: 'p1', shopId: 'shop-1', currentStock: 5, reorderLevel: 24, safetyStock: 10, targetStockLevel: 48, allowNegativeStock: false },
  { productId: 'p2', shopId: 'shop-1', currentStock: 2, reorderLevel: 12, safetyStock: 5, targetStockLevel: 24, allowNegativeStock: false },
  { productId: 'p3', shopId: 'shop-1', currentStock: 18, reorderLevel: 20, safetyStock: 8, targetStockLevel: 40, allowNegativeStock: false },
  { productId: 'p4', shopId: 'shop-1', currentStock: 30, reorderLevel: 20, safetyStock: 8, targetStockLevel: 40, allowNegativeStock: false },
  { productId: 'p5', shopId: 'shop-1', currentStock: 3, reorderLevel: 24, safetyStock: 10, targetStockLevel: 48, allowNegativeStock: false },
  { productId: 'p6', shopId: 'shop-1', currentStock: 22, reorderLevel: 20, safetyStock: 8, targetStockLevel: 40, allowNegativeStock: false },
  { productId: 'p7', shopId: 'shop-1', currentStock: 8, reorderLevel: 20, safetyStock: 8, targetStockLevel: 40, allowNegativeStock: false },
  { productId: 'p8', shopId: 'shop-1', currentStock: 4, reorderLevel: 15, safetyStock: 5, targetStockLevel: 30, allowNegativeStock: false },
  { productId: 'p9', shopId: 'shop-1', currentStock: 12, reorderLevel: 15, safetyStock: 5, targetStockLevel: 30, allowNegativeStock: false },
  { productId: 'p10', shopId: 'shop-1', currentStock: 1, reorderLevel: 15, safetyStock: 5, targetStockLevel: 30, allowNegativeStock: false },
  { productId: 'p11', shopId: 'shop-1', currentStock: 6, reorderLevel: 20, safetyStock: 8, targetStockLevel: 40, allowNegativeStock: false },
  { productId: 'p12', shopId: 'shop-1', currentStock: 3, reorderLevel: 10, safetyStock: 4, targetStockLevel: 20, allowNegativeStock: false },
  { productId: 'p13', shopId: 'shop-1', currentStock: 8, reorderLevel: 8, safetyStock: 3, targetStockLevel: 16, allowNegativeStock: false },
  { productId: 'p14', shopId: 'shop-1', currentStock: 15, reorderLevel: 12, safetyStock: 5, targetStockLevel: 24, allowNegativeStock: false },
  { productId: 'p15', shopId: 'shop-1', currentStock: 2, reorderLevel: 10, safetyStock: 4, targetStockLevel: 20, allowNegativeStock: false },
  { productId: 'p16', shopId: 'shop-1', currentStock: 7, reorderLevel: 12, safetyStock: 5, targetStockLevel: 24, allowNegativeStock: false },
  { productId: 'p17', shopId: 'shop-1', currentStock: 4, reorderLevel: 8, safetyStock: 3, targetStockLevel: 16, allowNegativeStock: false },
];

export const productSupplierLinks: ProductSupplierLink[] = [
  { id: 'psl1', productId: 'p1', supplierId: 's1', supplierSku: 'MBL-CC330', isPreferred: true, leadTimeDays: 3, minOrderQty: 24, packSize: 24, lastPurchasePrice: 0.95 },
  { id: 'psl2', productId: 'p2', supplierId: 's1', supplierSku: 'MBL-CC1500', isPreferred: true, leadTimeDays: 3, minOrderQty: 12, packSize: 12, lastPurchasePrice: 1.80 },
  { id: 'psl3', productId: 'p3', supplierId: 's1', supplierSku: 'MBL-DC330', isPreferred: true, leadTimeDays: 3, minOrderQty: 24, packSize: 24, lastPurchasePrice: 0.95 },
  { id: 'psl4', productId: 'p4', supplierId: 's1', supplierSku: 'MBL-SP330', isPreferred: true, leadTimeDays: 3, minOrderQty: 24, packSize: 24, lastPurchasePrice: 0.88 },
  { id: 'psl5', productId: 'p5', supplierId: 's1', supplierSku: 'MBL-PP330', isPreferred: true, leadTimeDays: 3, minOrderQty: 24, packSize: 24, lastPurchasePrice: 0.95 },
  { id: 'psl6', productId: 'p6', supplierId: 's1', supplierSku: 'MBL-PM330', isPreferred: true, leadTimeDays: 3, minOrderQty: 24, packSize: 24, lastPurchasePrice: 0.95 },
  { id: 'psl7', productId: 'p7', supplierId: 's1', supplierSku: 'MBL-7U330', isPreferred: true, leadTimeDays: 3, minOrderQty: 24, packSize: 24, lastPurchasePrice: 0.88 },
  { id: 'psl8', productId: 'p8', supplierId: 's2', supplierSku: 'SWD-LYCL150', isPreferred: true, leadTimeDays: 5, minOrderQty: 12, packSize: 12, lastPurchasePrice: 2.10 },
  { id: 'psl9', productId: 'p9', supplierId: 's2', supplierSku: 'SWD-LYBB150', isPreferred: true, leadTimeDays: 5, minOrderQty: 12, packSize: 12, lastPurchasePrice: 2.10 },
  { id: 'psl10', productId: 'p10', supplierId: 's2', supplierSku: 'SWD-LYSC150', isPreferred: true, leadTimeDays: 5, minOrderQty: 12, packSize: 12, lastPurchasePrice: 2.10 },
  { id: 'psl11', productId: 'p11', supplierId: 's2', supplierSku: 'SWD-NSKK4F', isPreferred: true, leadTimeDays: 5, minOrderQty: 24, packSize: 24, lastPurchasePrice: 1.10 },
  { id: 'psl12', productId: 'p12', supplierId: 's4', supplierSku: 'FFD-NSMI400', isPreferred: true, leadTimeDays: 2, minOrderQty: 6, packSize: 6, lastPurchasePrice: 3.80 },
  { id: 'psl13', productId: 'p13', supplierId: 's4', supplierSku: 'FFD-NSNC200', isPreferred: true, leadTimeDays: 2, minOrderQty: 6, packSize: 6, lastPurchasePrice: 6.20 },
  { id: 'psl14', productId: 'p14', supplierId: 's3', supplierSku: 'HSC-DTSP100', isPreferred: true, leadTimeDays: 7, minOrderQty: 24, packSize: 24, lastPurchasePrice: 1.30 },
  { id: 'psl15', productId: 'p15', supplierId: 's3', supplierSku: 'HSC-DTHW250', isPreferred: true, leadTimeDays: 7, minOrderQty: 12, packSize: 12, lastPurchasePrice: 2.20 },
  { id: 'psl16', productId: 'p16', supplierId: 's3', supplierSku: 'HSC-CGTT150', isPreferred: true, leadTimeDays: 7, minOrderQty: 12, packSize: 12, lastPurchasePrice: 2.50 },
  { id: 'psl17', productId: 'p17', supplierId: 's3', supplierSku: 'HSC-CGMW500', isPreferred: true, leadTimeDays: 7, minOrderQty: 6, packSize: 6, lastPurchasePrice: 3.40 },
];

export const initialDraftOrders: DraftOrder[] = [
  {
    id: 'do1',
    supplierId: 's1',
    supplierName: 'Metro Beverages Ltd',
    status: 'Draft',
    lines: [
      { productId: 'p1', productName: 'Coca-Cola 330ml', sku: 'CC-330', qty: 48, unitCost: 0.95, total: 45.60 },
      { productId: 'p2', productName: 'Coca-Cola 1.5L', sku: 'CC-1500', qty: 24, unitCost: 1.80, total: 43.20 },
    ],
    notes: 'Urgent restock needed',
    createdAt: '2026-04-03',
    totalAmount: 88.80,
  },
];

export const defaultShopSettings: ShopStockSettings = {
  lowStockThreshold: 20,
  safetyStock: 8,
  leadTimeDays: 5,
  targetDaysOfCover: 14,
};
