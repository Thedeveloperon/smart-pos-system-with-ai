import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Save } from 'lucide-react';
import { defaultShopSettings, products, shopInventory } from '@/data/mockData';
import type { ShopStockSettings, ShopInventory } from '@/data/types';

interface SettingsTabProps {
  selectedShopId: string;
}

export default function SettingsTab({ selectedShopId }: SettingsTabProps) {
  const [settings, setSettings] = useState<ShopStockSettings>(defaultShopSettings);
  const [inventory, setInventory] = useState<ShopInventory[]>(
    shopInventory.filter(i => i.shopId === selectedShopId)
  );

  const updateInventory = (productId: string, field: keyof ShopInventory, value: number | boolean) => {
    setInventory(prev => prev.map(i =>
      i.productId === productId ? { ...i, [field]: value } : i
    ));
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Default Thresholds</CardTitle>
          <CardDescription>These defaults apply to new products added to this shop</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            <div>
              <Label>Low Stock Threshold</Label>
              <Input type="number" value={settings.lowStockThreshold}
                onChange={e => setSettings(s => ({ ...s, lowStockThreshold: +e.target.value }))} />
            </div>
            <div>
              <Label>Safety Stock</Label>
              <Input type="number" value={settings.safetyStock}
                onChange={e => setSettings(s => ({ ...s, safetyStock: +e.target.value }))} />
            </div>
            <div>
              <Label>Lead Time (days)</Label>
              <Input type="number" value={settings.leadTimeDays}
                onChange={e => setSettings(s => ({ ...s, leadTimeDays: +e.target.value }))} />
            </div>
            <div>
              <Label>Target Days of Cover</Label>
              <Input type="number" value={settings.targetDaysOfCover}
                onChange={e => setSettings(s => ({ ...s, targetDaysOfCover: +e.target.value }))} />
            </div>
          </div>
          <Button className="mt-4" size="sm"><Save className="mr-1 h-4 w-4" /> Save Defaults</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Per-Product Inventory Settings</CardTitle>
          <CardDescription>Override default thresholds for individual products</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-lg border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product</TableHead>
                  <TableHead className="text-right">Reorder Level</TableHead>
                  <TableHead className="text-right">Safety Stock</TableHead>
                  <TableHead className="text-right">Target Level</TableHead>
                  <TableHead className="text-center">Allow Negative</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {inventory.map(inv => {
                  const product = products.find(p => p.id === inv.productId);
                  return (
                    <TableRow key={inv.productId}>
                      <TableCell className="font-medium">{product?.name}</TableCell>
                      <TableCell className="text-right">
                        <Input type="number" className="ml-auto w-20 text-right" value={inv.reorderLevel}
                          onChange={e => updateInventory(inv.productId, 'reorderLevel', +e.target.value)} />
                      </TableCell>
                      <TableCell className="text-right">
                        <Input type="number" className="ml-auto w-20 text-right" value={inv.safetyStock}
                          onChange={e => updateInventory(inv.productId, 'safetyStock', +e.target.value)} />
                      </TableCell>
                      <TableCell className="text-right">
                        <Input type="number" className="ml-auto w-20 text-right" value={inv.targetStockLevel}
                          onChange={e => updateInventory(inv.productId, 'targetStockLevel', +e.target.value)} />
                      </TableCell>
                      <TableCell className="text-center">
                        <Switch checked={inv.allowNegativeStock}
                          onCheckedChange={v => updateInventory(inv.productId, 'allowNegativeStock', v)} />
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
          <Button className="mt-4" size="sm"><Save className="mr-1 h-4 w-4" /> Save Settings</Button>
        </CardContent>
      </Card>
    </div>
  );
}
