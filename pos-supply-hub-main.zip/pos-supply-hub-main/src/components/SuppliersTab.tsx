import { useState } from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Plus, Pencil, ArrowLeft, Star } from 'lucide-react';
import { suppliers as initialSuppliers, productSupplierLinks, products } from '@/data/mockData';
import type { Supplier, ProductSupplierLink } from '@/data/types';

const emptyForm = (): Omit<Supplier, 'id'> => ({
  name: '', code: '', contactPerson: '', phone: '', email: '', address: '',
  defaultLeadTimeDays: 5, paymentTerms: 'Net 30', notes: '', isActive: true,
});

export default function SuppliersTab() {
  const [supplierList, setSupplierList] = useState(initialSuppliers);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Supplier | null>(null);
  const [form, setForm] = useState(emptyForm());
  const [selectedSupplier, setSelectedSupplier] = useState<Supplier | null>(null);

  const openAdd = () => { setEditing(null); setForm(emptyForm()); setDialogOpen(true); };
  const openEdit = (s: Supplier) => { setEditing(s); const { id, ...rest } = s; setForm(rest); setDialogOpen(true); };

  const save = () => {
    if (editing) {
      setSupplierList(prev => prev.map(s => s.id === editing.id ? { ...s, ...form } : s));
    } else {
      setSupplierList(prev => [...prev, { id: `s${Date.now()}`, ...form }]);
    }
    setDialogOpen(false);
  };

  const set = (key: string, value: string | number | boolean) => setForm(f => ({ ...f, [key]: value }));

  const linkedProducts: (ProductSupplierLink & { productName: string; productSku: string })[] = selectedSupplier
    ? productSupplierLinks
        .filter(l => l.supplierId === selectedSupplier.id)
        .map(l => {
          const p = products.find(pr => pr.id === l.productId)!;
          return { ...l, productName: p.name, productSku: p.sku };
        })
    : [];

  if (selectedSupplier) {
    return (
      <div className="space-y-4">
        <Button variant="ghost" size="sm" onClick={() => setSelectedSupplier(null)}>
          <ArrowLeft className="mr-1 h-4 w-4" /> Back to Suppliers
        </Button>
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>{selectedSupplier.name}</CardTitle>
              <Badge variant={selectedSupplier.isActive ? 'default' : 'secondary'}>
                {selectedSupplier.isActive ? 'Active' : 'Inactive'}
              </Badge>
            </div>
            <div className="grid grid-cols-3 gap-4 pt-2 text-sm text-muted-foreground">
              <div><span className="font-medium text-foreground">Contact:</span> {selectedSupplier.contactPerson}</div>
              <div><span className="font-medium text-foreground">Phone:</span> {selectedSupplier.phone}</div>
              <div><span className="font-medium text-foreground">Email:</span> {selectedSupplier.email}</div>
              <div><span className="font-medium text-foreground">Lead Time:</span> {selectedSupplier.defaultLeadTimeDays} days</div>
              <div><span className="font-medium text-foreground">Payment:</span> {selectedSupplier.paymentTerms}</div>
              <div><span className="font-medium text-foreground">Code:</span> {selectedSupplier.code}</div>
            </div>
          </CardHeader>
        </Card>

        <Card>
          <CardHeader className="py-3">
            <CardTitle className="text-base">Linked Products ({linkedProducts.length})</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product</TableHead>
                  <TableHead>Supplier SKU</TableHead>
                  <TableHead>Preferred</TableHead>
                  <TableHead className="text-right">Lead Time</TableHead>
                  <TableHead className="text-right">Min Order</TableHead>
                  <TableHead className="text-right">Pack Size</TableHead>
                  <TableHead className="text-right">Last Price</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {linkedProducts.map(l => (
                  <TableRow key={l.id}>
                    <TableCell className="font-medium">{l.productName}</TableCell>
                    <TableCell className="font-mono text-xs">{l.supplierSku}</TableCell>
                    <TableCell>{l.isPreferred ? <Star className="h-4 w-4 fill-warning text-warning" /> : '—'}</TableCell>
                    <TableCell className="text-right">{l.leadTimeDays}d</TableCell>
                    <TableCell className="text-right">{l.minOrderQty}</TableCell>
                    <TableCell className="text-right">{l.packSize}</TableCell>
                    <TableCell className="text-right">${l.lastPurchasePrice.toFixed(2)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Suppliers</h2>
        <Button onClick={openAdd} size="sm"><Plus className="mr-1 h-4 w-4" /> Add Supplier</Button>
      </div>

      <div className="rounded-lg border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Code</TableHead>
              <TableHead>Contact</TableHead>
              <TableHead>Phone</TableHead>
              <TableHead className="text-right">Products</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="w-16"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {supplierList.map(s => {
              const productCount = productSupplierLinks.filter(l => l.supplierId === s.id).length;
              return (
                <TableRow key={s.id} className="cursor-pointer" onClick={() => setSelectedSupplier(s)}>
                  <TableCell className="font-medium">{s.name}</TableCell>
                  <TableCell className="font-mono text-xs">{s.code}</TableCell>
                  <TableCell>{s.contactPerson}</TableCell>
                  <TableCell>{s.phone}</TableCell>
                  <TableCell className="text-right">{productCount}</TableCell>
                  <TableCell>
                    <Badge variant={s.isActive ? 'default' : 'secondary'}>
                      {s.isActive ? 'Active' : 'Inactive'}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); openEdit(s); }}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Supplier' : 'Add Supplier'}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div><Label>Name</Label><Input value={form.name} onChange={e => set('name', e.target.value)} /></div>
            <div><Label>Code</Label><Input value={form.code} onChange={e => set('code', e.target.value)} /></div>
            <div><Label>Contact Person</Label><Input value={form.contactPerson} onChange={e => set('contactPerson', e.target.value)} /></div>
            <div><Label>Phone</Label><Input value={form.phone} onChange={e => set('phone', e.target.value)} /></div>
            <div className="col-span-2"><Label>Email</Label><Input value={form.email} onChange={e => set('email', e.target.value)} /></div>
            <div className="col-span-2"><Label>Address</Label><Input value={form.address} onChange={e => set('address', e.target.value)} /></div>
            <div><Label>Lead Time (days)</Label><Input type="number" value={form.defaultLeadTimeDays} onChange={e => set('defaultLeadTimeDays', +e.target.value)} /></div>
            <div><Label>Payment Terms</Label><Input value={form.paymentTerms} onChange={e => set('paymentTerms', e.target.value)} /></div>
            <div className="col-span-2"><Label>Notes</Label><Textarea value={form.notes} onChange={e => set('notes', e.target.value)} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={save}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
