import { useState, useMemo } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { ShoppingCart, FileText, Check } from 'lucide-react';
import { products, shopInventory, productSupplierLinks, suppliers, initialDraftOrders } from '@/data/mockData';
import type { ReorderSuggestion, DraftOrder, DraftOrderLine } from '@/data/types';

interface ReorderTabProps {
  selectedShopId: string;
}

export default function ReorderTab({ selectedShopId }: ReorderTabProps) {
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [drafts, setDrafts] = useState<DraftOrder[]>(initialDraftOrders);
  const [reviewDraft, setReviewDraft] = useState<DraftOrder | null>(null);
  const [draftDialogOpen, setDraftDialogOpen] = useState(false);
  const [draftNotes, setDraftNotes] = useState('');

  const suggestions: ReorderSuggestion[] = useMemo(() => {
    return shopInventory
      .filter(inv => inv.shopId === selectedShopId && inv.currentStock < inv.reorderLevel)
      .map(inv => {
        const product = products.find(p => p.id === inv.productId)!;
        const link = productSupplierLinks.find(l => l.productId === inv.productId && l.isPreferred);
        const supplier = link ? suppliers.find(s => s.id === link.supplierId) : undefined;
        return {
          id: inv.productId,
          product,
          supplierId: link?.supplierId || '',
          supplierName: supplier?.name || 'Unassigned',
          currentStock: inv.currentStock,
          reorderLevel: inv.reorderLevel,
          suggestedQty: inv.targetStockLevel - inv.currentStock,
          lastCost: link?.lastPurchasePrice || 0,
          leadTimeDays: link?.leadTimeDays || 0,
        };
      })
      .sort((a, b) => (b.reorderLevel - b.currentStock) - (a.reorderLevel - a.currentStock));
  }, [selectedShopId]);

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const toggleAll = () => {
    if (selectedIds.size === suggestions.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(suggestions.map(s => s.id)));
    }
  };

  const createDraft = () => {
    const selected = suggestions.filter(s => selectedIds.has(s.id));
    const grouped = new Map<string, typeof selected>();
    selected.forEach(s => {
      if (!grouped.has(s.supplierId)) grouped.set(s.supplierId, []);
      grouped.get(s.supplierId)!.push(s);
    });

    const newDrafts: DraftOrder[] = Array.from(grouped.entries()).map(([supplierId, items]) => {
      const lines: DraftOrderLine[] = items.map(item => ({
        productId: item.product.id,
        productName: item.product.name,
        sku: item.product.sku,
        qty: item.suggestedQty,
        unitCost: item.lastCost,
        total: item.suggestedQty * item.lastCost,
      }));
      return {
        id: `do${Date.now()}-${supplierId}`,
        supplierId,
        supplierName: items[0].supplierName,
        status: 'Draft' as const,
        lines,
        notes: '',
        createdAt: new Date().toISOString().split('T')[0],
        totalAmount: lines.reduce((s, l) => s + l.total, 0),
      };
    });

    setDrafts(prev => [...prev, ...newDrafts]);
    setSelectedIds(new Set());
  };

  const confirmDraft = (draftId: string) => {
    setDrafts(prev => prev.map(d => d.id === draftId ? { ...d, status: 'Confirmed' as const } : d));
    setReviewDraft(null);
  };

  const openReview = (draft: DraftOrder) => {
    setReviewDraft(draft);
    setDraftNotes(draft.notes);
    setDraftDialogOpen(true);
  };

  return (
    <div className="space-y-4">
      <Tabs defaultValue="suggestions">
        <TabsList>
          <TabsTrigger value="suggestions">
            <ShoppingCart className="mr-1 h-4 w-4" /> Suggestions ({suggestions.length})
          </TabsTrigger>
          <TabsTrigger value="drafts">
            <FileText className="mr-1 h-4 w-4" /> Drafts ({drafts.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="suggestions">
          <div className="space-y-3">
            {selectedIds.size > 0 && (
              <div className="flex items-center gap-3 rounded-lg border bg-primary/5 p-3">
                <span className="text-sm font-medium">{selectedIds.size} items selected</span>
                <Button size="sm" onClick={createDraft}>Create Draft Order</Button>
              </div>
            )}
            <div className="rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-10">
                      <Checkbox checked={selectedIds.size === suggestions.length && suggestions.length > 0} onCheckedChange={toggleAll} />
                    </TableHead>
                    <TableHead>Product</TableHead>
                    <TableHead>Brand</TableHead>
                    <TableHead>Supplier</TableHead>
                    <TableHead className="text-right">Current</TableHead>
                    <TableHead className="text-right">Suggested Qty</TableHead>
                    <TableHead className="text-right">Last Cost</TableHead>
                    <TableHead className="text-right">Est. Total</TableHead>
                    <TableHead className="text-right">Lead Time</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {suggestions.map(s => (
                    <TableRow key={s.id}>
                      <TableCell>
                        <Checkbox checked={selectedIds.has(s.id)} onCheckedChange={() => toggleSelect(s.id)} />
                      </TableCell>
                      <TableCell className="font-medium">{s.product.name}</TableCell>
                      <TableCell>{s.product.brandName}</TableCell>
                      <TableCell>{s.supplierName}</TableCell>
                      <TableCell className="text-right">{s.currentStock}</TableCell>
                      <TableCell className="text-right font-medium">{s.suggestedQty}</TableCell>
                      <TableCell className="text-right">${s.lastCost.toFixed(2)}</TableCell>
                      <TableCell className="text-right">${(s.suggestedQty * s.lastCost).toFixed(2)}</TableCell>
                      <TableCell className="text-right">{s.leadTimeDays}d</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="drafts">
          <div className="grid gap-3">
            {drafts.map(draft => (
              <Card key={draft.id}>
                <CardHeader className="py-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-base">{draft.supplierName}</CardTitle>
                      <CardDescription>{draft.lines.length} items · Created {draft.createdAt}</CardDescription>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-lg font-semibold">${draft.totalAmount.toFixed(2)}</span>
                      <Badge variant={draft.status === 'Confirmed' ? 'default' : 'secondary'}>
                        {draft.status === 'Confirmed' && <Check className="mr-1 h-3 w-3" />}
                        {draft.status}
                      </Badge>
                      <Button size="sm" variant="outline" onClick={() => openReview(draft)}>Review</Button>
                    </div>
                  </div>
                </CardHeader>
              </Card>
            ))}
            {drafts.length === 0 && (
              <Card>
                <CardContent className="py-8 text-center text-muted-foreground">
                  No draft orders yet. Select items from Suggestions to create one.
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>
      </Tabs>

      <Dialog open={draftDialogOpen} onOpenChange={setDraftDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Draft Purchase Order — {reviewDraft?.supplierName}</DialogTitle>
          </DialogHeader>
          {reviewDraft && (
            <div className="space-y-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Product</TableHead>
                    <TableHead>SKU</TableHead>
                    <TableHead className="text-right">Qty</TableHead>
                    <TableHead className="text-right">Unit Cost</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {reviewDraft.lines.map(line => (
                    <TableRow key={line.productId}>
                      <TableCell>{line.productName}</TableCell>
                      <TableCell className="font-mono text-xs">{line.sku}</TableCell>
                      <TableCell className="text-right">{line.qty}</TableCell>
                      <TableCell className="text-right">${line.unitCost.toFixed(2)}</TableCell>
                      <TableCell className="text-right font-medium">${line.total.toFixed(2)}</TableCell>
                    </TableRow>
                  ))}
                  <TableRow>
                    <TableCell colSpan={4} className="text-right font-semibold">Total</TableCell>
                    <TableCell className="text-right font-bold">${reviewDraft.totalAmount.toFixed(2)}</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
              <div>
                <label className="mb-1 block text-sm font-medium">Notes</label>
                <Textarea value={draftNotes} onChange={e => setDraftNotes(e.target.value)} placeholder="Add notes..." />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDraftDialogOpen(false)}>Close</Button>
            {reviewDraft?.status === 'Draft' && (
              <Button onClick={() => { confirmDraft(reviewDraft!.id); setDraftDialogOpen(false); }}>
                <Check className="mr-1 h-4 w-4" /> Confirm Order
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
