import { useState, useMemo } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { ChevronDown, ChevronRight, AlertTriangle, Package } from 'lucide-react';
import { products, shopInventory, productSupplierLinks, suppliers, brands, shops } from '@/data/mockData';
import type { LowStockItem } from '@/data/types';

interface LowStockTabProps {
  selectedShopId: string;
}

export default function LowStockTab({ selectedShopId }: LowStockTabProps) {
  const [brandFilter, setBrandFilter] = useState('all');
  const [supplierFilter, setSupplierFilter] = useState('all');
  const [thresholdMultiplier, setThresholdMultiplier] = useState([1]);
  const [expandedBrands, setExpandedBrands] = useState<Set<string>>(new Set());
  const [expandedSuppliers, setExpandedSuppliers] = useState<Set<string>>(new Set());

  const lowStockItems: LowStockItem[] = useMemo(() => {
    const shop = shops.find(s => s.id === selectedShopId);
    return shopInventory
      .filter(inv => inv.shopId === selectedShopId)
      .map(inv => {
        const product = products.find(p => p.id === inv.productId)!;
        const link = productSupplierLinks.find(l => l.productId === inv.productId && l.isPreferred);
        const supplier = link ? suppliers.find(s => s.id === link.supplierId) : undefined;
        const effectiveReorder = Math.ceil(inv.reorderLevel * thresholdMultiplier[0]);
        const deficit = effectiveReorder - inv.currentStock;
        return {
          product,
          shopId: selectedShopId,
          shopName: shop?.name || '',
          currentStock: inv.currentStock,
          reorderLevel: effectiveReorder,
          deficit,
          preferredSupplier: supplier?.name,
          lastPurchasePrice: link?.lastPurchasePrice || 0,
        };
      })
      .filter(item => item.deficit > 0)
      .filter(item => brandFilter === 'all' || item.product.brandId === brandFilter)
      .filter(item => {
        if (supplierFilter === 'all') return true;
        const link = productSupplierLinks.find(l => l.productId === item.product.id && l.isPreferred);
        return link?.supplierId === supplierFilter;
      })
      .sort((a, b) => b.deficit - a.deficit);
  }, [selectedShopId, brandFilter, supplierFilter, thresholdMultiplier]);

  const byBrand = useMemo(() => {
    const grouped = new Map<string, LowStockItem[]>();
    lowStockItems.forEach(item => {
      const key = item.product.brandId;
      if (!grouped.has(key)) grouped.set(key, []);
      grouped.get(key)!.push(item);
    });
    return Array.from(grouped.entries()).map(([brandId, items]) => {
      const brand = brands.find(b => b.id === brandId)!;
      return {
        brand,
        items,
        totalDeficit: items.reduce((s, i) => s + i.deficit, 0),
        estimatedValue: items.reduce((s, i) => s + i.deficit * i.lastPurchasePrice, 0),
      };
    });
  }, [lowStockItems]);

  const bySupplier = useMemo(() => {
    const grouped = new Map<string, LowStockItem[]>();
    lowStockItems.forEach(item => {
      const link = productSupplierLinks.find(l => l.productId === item.product.id && l.isPreferred);
      const key = link?.supplierId || 'unknown';
      if (!grouped.has(key)) grouped.set(key, []);
      grouped.get(key)!.push(item);
    });
    return Array.from(grouped.entries()).map(([supplierId, items]) => {
      const supplier = suppliers.find(s => s.id === supplierId);
      return {
        supplierName: supplier?.name || 'Unknown',
        supplierId,
        items,
        totalDeficit: items.reduce((s, i) => s + i.deficit, 0),
        estimatedCost: items.reduce((s, i) => s + i.deficit * i.lastPurchasePrice, 0),
      };
    });
  }, [lowStockItems]);

  const getDeficitBadge = (deficit: number, reorderLevel: number) => {
    const ratio = deficit / reorderLevel;
    if (ratio > 0.7) return <Badge className="bg-destructive text-destructive-foreground">{deficit}</Badge>;
    if (ratio > 0.3) return <Badge className="bg-warning text-warning-foreground">{deficit}</Badge>;
    return <Badge className="bg-success text-success-foreground">{deficit}</Badge>;
  };

  const toggleBrand = (id: string) => {
    setExpandedBrands(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const toggleSupplier = (id: string) => {
    setExpandedSuppliers(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex flex-wrap items-end gap-4 rounded-lg border bg-card p-4">
        <div className="w-48">
          <label className="mb-1.5 block text-xs font-medium text-muted-foreground">Brand</label>
          <Select value={brandFilter} onValueChange={setBrandFilter}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Brands</SelectItem>
              {brands.filter(b => b.isActive).map(b => (
                <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="w-48">
          <label className="mb-1.5 block text-xs font-medium text-muted-foreground">Supplier</label>
          <Select value={supplierFilter} onValueChange={setSupplierFilter}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Suppliers</SelectItem>
              {suppliers.filter(s => s.isActive).map(s => (
                <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="w-64">
          <label className="mb-1.5 block text-xs font-medium text-muted-foreground">
            Threshold Multiplier: {thresholdMultiplier[0].toFixed(1)}x
          </label>
          <Slider value={thresholdMultiplier} onValueChange={setThresholdMultiplier} min={0.5} max={2} step={0.1} />
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <AlertTriangle className="h-4 w-4 text-warning" />
          {lowStockItems.length} items below threshold
        </div>
      </div>

      <Tabs defaultValue="byShop">
        <TabsList>
          <TabsTrigger value="byShop">By Shop</TabsTrigger>
          <TabsTrigger value="byBrand">By Brand</TabsTrigger>
          <TabsTrigger value="bySupplier">By Supplier</TabsTrigger>
        </TabsList>

        <TabsContent value="byShop">
          <div className="rounded-lg border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product</TableHead>
                  <TableHead>Brand</TableHead>
                  <TableHead>SKU</TableHead>
                  <TableHead className="text-right">Current</TableHead>
                  <TableHead className="text-right">Reorder Lvl</TableHead>
                  <TableHead className="text-right">Deficit</TableHead>
                  <TableHead>Preferred Supplier</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {lowStockItems.map(item => (
                  <TableRow key={item.product.id}>
                    <TableCell className="font-medium">{item.product.name}</TableCell>
                    <TableCell>{item.product.brandName}</TableCell>
                    <TableCell className="font-mono text-xs">{item.product.sku}</TableCell>
                    <TableCell className="text-right">{item.currentStock}</TableCell>
                    <TableCell className="text-right">{item.reorderLevel}</TableCell>
                    <TableCell className="text-right">{getDeficitBadge(item.deficit, item.reorderLevel)}</TableCell>
                    <TableCell>{item.preferredSupplier || '—'}</TableCell>
                  </TableRow>
                ))}
                {lowStockItems.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={7} className="py-8 text-center text-muted-foreground">
                      <Package className="mx-auto mb-2 h-8 w-8" />
                      All items are above threshold
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="byBrand">
          <div className="grid gap-3">
            {byBrand.map(({ brand, items, totalDeficit, estimatedValue }) => (
              <Card key={brand.id} className="cursor-pointer" onClick={() => toggleBrand(brand.id)}>
                <CardHeader className="py-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {expandedBrands.has(brand.id) ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                      <CardTitle className="text-base">{brand.name}</CardTitle>
                    </div>
                    <div className="flex items-center gap-4 text-sm">
                      <span className="text-muted-foreground">{items.length} items</span>
                      <Badge variant="destructive">Deficit: {totalDeficit}</Badge>
                      <span className="font-medium">${estimatedValue.toFixed(2)}</span>
                    </div>
                  </div>
                </CardHeader>
                {expandedBrands.has(brand.id) && (
                  <CardContent className="pt-0">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Product</TableHead>
                          <TableHead className="text-right">Current</TableHead>
                          <TableHead className="text-right">Deficit</TableHead>
                          <TableHead className="text-right">Est. Cost</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {items.map(item => (
                          <TableRow key={item.product.id}>
                            <TableCell>{item.product.name}</TableCell>
                            <TableCell className="text-right">{item.currentStock}</TableCell>
                            <TableCell className="text-right">{getDeficitBadge(item.deficit, item.reorderLevel)}</TableCell>
                            <TableCell className="text-right">${(item.deficit * item.lastPurchasePrice).toFixed(2)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                )}
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="bySupplier">
          <div className="grid gap-3">
            {bySupplier.map(({ supplierName, supplierId, items, totalDeficit, estimatedCost }) => (
              <Card key={supplierId} className="cursor-pointer" onClick={() => toggleSupplier(supplierId)}>
                <CardHeader className="py-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {expandedSuppliers.has(supplierId) ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                      <CardTitle className="text-base">{supplierName}</CardTitle>
                    </div>
                    <div className="flex items-center gap-4 text-sm">
                      <span className="text-muted-foreground">{items.length} items</span>
                      <Badge variant="destructive">Deficit: {totalDeficit}</Badge>
                      <span className="font-medium">${estimatedCost.toFixed(2)}</span>
                    </div>
                  </div>
                </CardHeader>
                {expandedSuppliers.has(supplierId) && (
                  <CardContent className="pt-0">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Product</TableHead>
                          <TableHead>Brand</TableHead>
                          <TableHead className="text-right">Current</TableHead>
                          <TableHead className="text-right">Deficit</TableHead>
                          <TableHead className="text-right">Est. Cost</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {items.map(item => (
                          <TableRow key={item.product.id}>
                            <TableCell>{item.product.name}</TableCell>
                            <TableCell>{item.product.brandName}</TableCell>
                            <TableCell className="text-right">{item.currentStock}</TableCell>
                            <TableCell className="text-right">{getDeficitBadge(item.deficit, item.reorderLevel)}</TableCell>
                            <TableCell className="text-right">${(item.deficit * item.lastPurchasePrice).toFixed(2)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                )}
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
