import { useState } from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Plus, Pencil, ChevronDown, ChevronRight } from 'lucide-react';
import { brands as initialBrands, products } from '@/data/mockData';
import type { Brand } from '@/data/types';

export default function BrandsTab() {
  const [brandList, setBrandList] = useState<Brand[]>(initialBrands);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingBrand, setEditingBrand] = useState<Brand | null>(null);
  const [expandedBrand, setExpandedBrand] = useState<string | null>(null);
  const [form, setForm] = useState({ name: '', code: '', isActive: true });

  const openAdd = () => {
    setEditingBrand(null);
    setForm({ name: '', code: '', isActive: true });
    setDialogOpen(true);
  };

  const openEdit = (brand: Brand) => {
    setEditingBrand(brand);
    setForm({ name: brand.name, code: brand.code, isActive: brand.isActive });
    setDialogOpen(true);
  };

  const save = () => {
    if (editingBrand) {
      setBrandList(prev => prev.map(b => b.id === editingBrand.id ? { ...b, ...form } : b));
    } else {
      const newBrand: Brand = {
        id: `b${Date.now()}`,
        ...form,
        productCount: 0,
      };
      setBrandList(prev => [...prev, newBrand]);
    }
    setDialogOpen(false);
  };

  const brandProducts = expandedBrand ? products.filter(p => p.brandId === expandedBrand) : [];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Brands</h2>
        <Button onClick={openAdd} size="sm"><Plus className="mr-1 h-4 w-4" /> Add Brand</Button>
      </div>

      <div className="rounded-lg border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-8"></TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Code</TableHead>
              <TableHead className="text-right">Products</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="w-16"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {brandList.map(brand => (
              <>
                <TableRow key={brand.id} className="cursor-pointer" onClick={() => setExpandedBrand(expandedBrand === brand.id ? null : brand.id)}>
                  <TableCell>
                    {expandedBrand === brand.id ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                  </TableCell>
                  <TableCell className="font-medium">{brand.name}</TableCell>
                  <TableCell className="font-mono text-xs">{brand.code}</TableCell>
                  <TableCell className="text-right">{brand.productCount}</TableCell>
                  <TableCell>
                    <Badge variant={brand.isActive ? 'default' : 'secondary'}>
                      {brand.isActive ? 'Active' : 'Inactive'}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); openEdit(brand); }}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
                {expandedBrand === brand.id && (
                  <TableRow key={`${brand.id}-expanded`}>
                    <TableCell colSpan={6} className="bg-muted/30 p-4">
                      <Card>
                        <CardHeader className="py-2">
                          <CardTitle className="text-sm">Products under {brand.name}</CardTitle>
                        </CardHeader>
                        <CardContent className="pt-0">
                          {brandProducts.length > 0 ? (
                            <Table>
                              <TableHeader>
                                <TableRow>
                                  <TableHead>Product Name</TableHead>
                                  <TableHead>SKU</TableHead>
                                  <TableHead>Category</TableHead>
                                  <TableHead className="text-right">Price</TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {brandProducts.map(p => (
                                  <TableRow key={p.id}>
                                    <TableCell>{p.name}</TableCell>
                                    <TableCell className="font-mono text-xs">{p.sku}</TableCell>
                                    <TableCell>{p.category}</TableCell>
                                    <TableCell className="text-right">${p.unitPrice.toFixed(2)}</TableCell>
                                  </TableRow>
                                ))}
                              </TableBody>
                            </Table>
                          ) : (
                            <p className="py-4 text-center text-sm text-muted-foreground">No products found</p>
                          )}
                        </CardContent>
                      </Card>
                    </TableCell>
                  </TableRow>
                )}
              </>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingBrand ? 'Edit Brand' : 'Add Brand'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Name</Label>
              <Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
            </div>
            <div>
              <Label>Code</Label>
              <Input value={form.code} onChange={e => setForm(f => ({ ...f, code: e.target.value }))} />
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={form.isActive} onCheckedChange={v => setForm(f => ({ ...f, isActive: v }))} />
              <Label>Active</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={save}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
