
# POS Supplier & Stock Management UI

## Overview
Build a complete supplier management and stock planning frontend for a POS system with mock data, clean minimal design, and top-tab navigation. Covers all 3 phases from the design doc.

## Layout
- **Top navigation bar** with the POS system name and a shop selector dropdown
- **Tab bar** below the nav with tabs: **Low Stock** | **Brands** | **Suppliers** | **Reorder** | **Settings**

## Pages & Features

### 1. Low Stock Report (default tab)
- Three sub-tabs: **By Shop** | **By Brand** | **By Supplier**
- **By Shop**: Table showing product, brand, SKU, current stock, reorder level, deficit, preferred supplier. Color-coded deficit badges (red for critical, amber for warning)
- **By Brand**: Cards per brand showing low-stock count, total deficit, estimated reorder value. Expandable to see individual products
- **By Supplier**: Cards per supplier showing items to order, total deficit, estimated cost. Expandable list of affected products
- Filters: brand dropdown, supplier dropdown, threshold slider

### 2. Brands Management
- Table of brands with name, code, product count, status toggle
- Add/edit brand dialog (name, code, active status)
- Click a brand to see its products listed

### 3. Suppliers Management
- Table of suppliers with name, code, contact info, product count
- Add/edit supplier dialog with all fields (name, code, contact, phone, email, address, lead time, payment terms, notes)
- **Product-Supplier Mapping**: Within a supplier detail view, show linked products with supplier SKU, item name, preferred status, lead time, min order qty, pack size, last purchase price
- Ability to link/unlink products to suppliers

### 4. Reorder Suggestions & Drafts
- **Suggestions tab**: Auto-generated table of products needing reorder with product, brand, supplier, current qty, suggested order qty, last cost, lead time. Checkboxes to select items
- **Create Draft**: Select items → group by supplier → review draft purchase order with line items, quantities, unit costs, totals, and notes field
- **Draft list**: View existing drafts with status (Draft/Confirmed), ability to review and confirm
- Confirm action converts draft to purchase bill

### 5. Shop Stock Settings
- Form for default thresholds: low stock threshold, safety stock, lead time days, target days of cover
- Per-product inventory settings: inline-editable table with reorder level, safety stock, target stock level, allow negative stock toggle

## Design Details
- Clean white background, subtle gray borders, professional typography
- Status badges: red for critical low stock, amber for warning, green for healthy
- Consistent card/table styling using shadcn/ui components
- Responsive layout that works on desktop
- All data is mock/demo data with realistic POS product names (beverages, snacks, household items)

## Tech
- React pages with React Router for tab navigation
- shadcn/ui components (Table, Card, Badge, Dialog, Tabs, Select, Input)
- Mock data service layer that can be swapped for real API calls later
- TypeScript interfaces matching the DTOs from the design doc
